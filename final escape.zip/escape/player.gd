extends CharacterBody2D
# Anexar no nó raiz "player" (CharacterBody2D) da cena player.tscn.
# Substitui o conteúdo do res://player.gd.

@export var velocidade := 80.0
@export var zoom_camera := 3.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var camera: Camera2D = $Camera2D

func _ready() -> void:
	add_to_group("jogador")
	# Jogo visto de cima: sem gravidade nem "chão"
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	camera.zoom = Vector2(zoom_camera, zoom_camera)
	# Adiciona WASD além das setas
	_adicionar_tecla("ui_left", KEY_A)
	_adicionar_tecla("ui_right", KEY_D)
	_adicionar_tecla("ui_up", KEY_W)
	_adicionar_tecla("ui_down", KEY_S)
	sprite.play("idle")

func _physics_process(_delta: float) -> void:
	var direcao := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direcao * velocidade

	# move_and_slide resolve a colisão com as paredes
	move_and_slide()

	# Animações
	if direcao != Vector2.ZERO:
		sprite.play("walk")
		if direcao.x != 0.0:
			sprite.flip_h = direcao.x < 0.0
	else:
		sprite.play("idle")

func _adicionar_tecla(acao: String, tecla: Key) -> void:
	for ev in InputMap.action_get_events(acao):
		if ev is InputEventKey and ev.physical_keycode == tecla:
			return
	var novo := InputEventKey.new()
	novo.physical_keycode = tecla
	InputMap.action_add_event(acao, novo)
